"""Command-line entry point required by the A-Maze-ing subject."""

from generator import main


if __name__ == "__main__":
    main()
